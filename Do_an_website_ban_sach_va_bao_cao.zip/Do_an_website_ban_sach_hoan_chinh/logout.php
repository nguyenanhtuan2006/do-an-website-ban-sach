<?php
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_is_valid($_POST['_csrf'] ?? '')) {
  header('Location: account.php');
  exit;
}
unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_email']);
session_regenerate_id(true);
header('Location: account.php?loggedout=1');
exit;

USE ban_sach;

INSERT INTO books (title, author, price, description)
SELECT seed.title, seed.author, seed.price, seed.description
FROM (
  SELECT 'Tắt Đèn' AS title, 'Ngô Tất Tố' AS author, 65000 AS price, 'Tiểu thuyết hiện thực nổi tiếng về cuộc sống người nông dân Việt Nam.' AS description
  UNION ALL SELECT 'Truyện Kiều', 'Nguyễn Du', 70000, 'Kiệt tác văn học cổ điển Việt Nam, giàu giá trị nhân văn và nghệ thuật.'
  UNION ALL SELECT 'Lão Hạc', 'Nam Cao', 45000, 'Tác phẩm văn học về tình phụ tử và số phận người nông dân.'
  UNION ALL SELECT 'Vợ Nhặt', 'Kim Lân', 55000, 'Truyện ngắn giàu tình người trong bối cảnh nạn đói năm 1945.'
  UNION ALL SELECT 'Cây Cam Ngọt Của Tôi', 'José Mauro de Vasconcelos', 105000, 'Câu chuyện cảm động về tuổi thơ, gia đình và lòng trắc ẩn.'
  UNION ALL SELECT 'Hoàng Tử Bé', 'Antoine de Saint-Exupéry', 55000, 'Tác phẩm kinh điển dành cho bạn đọc ở nhiều lứa tuổi.'
  UNION ALL SELECT 'Kính Vạn Hoa - Tập 1', 'Nguyễn Nhật Ánh', 62000, 'Tập mở đầu của bộ truyện thiếu nhi giàu tình bạn và tiếng cười.'
  UNION ALL SELECT 'Không Gia Đình', 'Hector Malot', 120000, 'Tiểu thuyết phiêu lưu kinh điển về hành trình trưởng thành.'
  UNION ALL SELECT 'Tôi Thấy Hoa Vàng Trên Cỏ Xanh', 'Nguyễn Nhật Ánh', 110000, 'Câu chuyện tuổi thơ trong trẻo ở một làng quê Việt Nam.'
  UNION ALL SELECT '7 Thói Quen Hiệu Quả', 'Stephen R. Covey', 175000, 'Những nguyên tắc phát triển bản thân và xây dựng thói quen tích cực.'
  UNION ALL SELECT 'Tư Duy Nhanh Và Chậm', 'Daniel Kahneman', 190000, 'Khám phá hai hệ thống tư duy và cách con người đưa ra quyết định.'
  UNION ALL SELECT 'Nghĩ Giàu Làm Giàu', 'Napoleon Hill', 90000, 'Tác phẩm kinh điển về tư duy mục tiêu, sự kiên trì và thành công.'
  UNION ALL SELECT 'Người Giàu Có Nhất Thành Babylon', 'George S. Clason', 85000, 'Những bài học tài chính cá nhân được kể qua các câu chuyện Babylon.'
  UNION ALL SELECT 'Để Con Được Ốm', 'Uyên Bùi, Nguyễn Trí Đoàn', 125000, 'Chia sẻ kiến thức chăm sóc sức khỏe trẻ nhỏ dành cho cha mẹ.'
  UNION ALL SELECT 'Bách Khoa Tri Thức Cho Trẻ Em', 'Nhiều tác giả', 155000, 'Tập hợp kiến thức phổ thông giúp trẻ khám phá thế giới xung quanh.'
) AS seed
WHERE NOT EXISTS (
  SELECT 1 FROM books AS existing_book WHERE existing_book.title = seed.title
);

<?php
require 'config.php';

$errors = [];
$success = !empty($_SESSION['contact_sent']);
unset($_SESSION['contact_sent']);

$form = [
    'full_name' => '',
    'email' => '',
    'phone' => '',
    'subject' => '',
    'message' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $key => $_) {
        $form[$key] = trim((string)($_POST[$key] ?? ''));
    }

    if (!csrf_is_valid((string)($_POST['_csrf'] ?? ''))) {
        $errors[] = 'Phiên gửi biểu mẫu không hợp lệ. Vui lòng tải lại trang và thử lại.';
    }
    if ($form['full_name'] === '' || strlen($form['full_name']) > 150) {
        $errors[] = 'Vui lòng nhập họ tên (không quá 150 ký tự).';
    }
    if (!filter_var($form['email'], FILTER_VALIDATE_EMAIL) || strlen($form['email']) > 190) {
        $errors[] = 'Vui lòng nhập địa chỉ email hợp lệ.';
    }
    if (strlen($form['phone']) > 30) {
        $errors[] = 'Số điện thoại không được dài quá 30 ký tự.';
    }
    if ($form['subject'] === '' || strlen($form['subject']) > 200) {
        $errors[] = 'Vui lòng nhập chủ đề (không quá 200 ký tự).';
    }
    if (strlen($form['message']) < 10 || strlen($form['message']) > 5000) {
        $errors[] = 'Nội dung cần có từ 10 đến 5.000 ký tự.';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO contact_messages (full_name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $form['full_name'],
                $form['email'],
                $form['phone'] !== '' ? $form['phone'] : null,
                $form['subject'],
                $form['message'],
            ]);
            $_SESSION['contact_sent'] = true;
            header('Location: contact.php');
            exit;
        } catch (PDOException $e) {
            $errors[] = 'Chưa lưu được lời nhắn. Hãy kiểm tra bảng contact_messages đã được tạo trong CSDL chưa.';
        }
    }
}

include 'header.php';
?>
<section class="contact-page">
  <div class="contact-intro">
    <div class="breadcrumbs"><a href="index.php">Trang chủ</a><span>/</span><span>Liên hệ</span></div>
    <span class="account-kicker">NHÀ SÁCH NHỎ · CHÚNG TÔI LUÔN LẮNG NGHE</span>
    <h1>Liên hệ với Nhà Sách Nhỏ</h1>
    <p>Gửi câu hỏi, góp ý hoặc yêu cầu hỗ trợ. Lời nhắn sẽ được lưu để cửa hàng xem lại.</p>
  </div>

  <div class="contact-layout">
    <aside class="contact-info-card">
      <span class="contact-icon" aria-hidden="true">✉</span>
      <h2>Gửi lời nhắn cho chúng tôi</h2>
      <p>Vui lòng điền đầy đủ thông tin và mô tả ngắn gọn vấn đề cần hỗ trợ.</p>
      <div class="contact-info-note">
        <strong>Thông tin đồ án</strong>
        <span>Nhà Sách Nhỏ · Website bán sách trực tuyến</span>
        <small>Biểu mẫu lưu dữ liệu vào bảng <code>contact_messages</code>. Phiên bản hiện tại chưa gửi email tự động.</small>
      </div>
    </aside>

    <section class="contact-form-card" aria-label="Biểu mẫu liên hệ">
      <?php if ($success): ?>
        <div class="contact-success" role="status">Cảm ơn bạn. Lời nhắn đã được lưu thành công.</div>
      <?php endif; ?>
      <?php if ($errors): ?>
        <div class="form-error" role="alert">
          <?php foreach ($errors as $error): ?>
            <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post" action="contact.php" class="contact-form">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
        <div class="contact-form-grid">
          <label><span class="contact-field-label">Họ và tên <b>*</b></span>
            <input type="text" name="full_name" maxlength="150" autocomplete="name" required value="<?= htmlspecialchars($form['full_name'], ENT_QUOTES, 'UTF-8') ?>">
          </label>
          <label><span class="contact-field-label">Email <b>*</b></span>
            <input type="email" name="email" maxlength="190" autocomplete="email" required value="<?= htmlspecialchars($form['email'], ENT_QUOTES, 'UTF-8') ?>">
          </label>
          <label><span class="contact-field-label">Số điện thoại <small>(không bắt buộc)</small></span>
            <input type="tel" name="phone" maxlength="30" autocomplete="tel" value="<?= htmlspecialchars($form['phone'], ENT_QUOTES, 'UTF-8') ?>">
          </label>
          <label><span class="contact-field-label">Chủ đề <b>*</b></span>
            <input type="text" name="subject" maxlength="200" required value="<?= htmlspecialchars($form['subject'], ENT_QUOTES, 'UTF-8') ?>">
          </label>
          <label class="contact-message-field"><span class="contact-field-label">Nội dung <b>*</b></span>
            <textarea name="message" rows="6" maxlength="5000" minlength="10" required><?= htmlspecialchars($form['message'], ENT_QUOTES, 'UTF-8') ?></textarea>
            <small>Từ 10 đến 5.000 ký tự.</small>
          </label>
        </div>
        <button class="contact-submit" type="submit">Gửi lời nhắn</button>
      </form>
    </section>
  </div>
</section>
<?php include 'footer.php'; ?>

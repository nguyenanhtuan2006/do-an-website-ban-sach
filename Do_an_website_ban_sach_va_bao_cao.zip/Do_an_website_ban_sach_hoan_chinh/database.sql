CREATE DATABASE IF NOT EXISTS ban_sach CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ban_sach;

CREATE TABLE IF NOT EXISTS books (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL,
 author VARCHAR(150) NOT NULL,
 price DECIMAL(12,2) NOT NULL DEFAULT 0,
 description TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(30) NOT NULL,
 address VARCHAR(500) NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NULL,
 customer_name VARCHAR(150) NOT NULL,
 phone VARCHAR(30) NOT NULL,
 customer_address VARCHAR(500) NOT NULL DEFAULT '',
 total DECIMAL(12,2) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 book_id INT NOT NULL,
 quantity INT NOT NULL DEFAULT 1,
 price DECIMAL(12,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS contact_messages (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL,
 phone VARCHAR(30) NULL,
 subject VARCHAR(200) NOT NULL,
 message TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Giá và mô tả dưới đây là dữ liệu minh họa cho đồ án.
INSERT INTO books(title,author,price,description) VALUES
('Dế Mèn Phiêu Lưu Ký','Tô Hoài',45000,'Tác phẩm văn học thiếu nhi nổi tiếng.'),
('Tuổi Trẻ Đáng Giá Bao Nhiêu','Rosie Nguyễn',80000,'Cuốn sách về học tập và trải nghiệm tuổi trẻ.'),
('Nhà Giả Kim','Paulo Coelho',75000,'Câu chuyện về hành trình theo đuổi ước mơ.'),
('Đắc Nhân Tâm','Dale Carnegie',90000,'Sách kỹ năng giao tiếp và ứng xử.'),
('Tắt Đèn','Ngô Tất Tố',65000,'Tiểu thuyết hiện thực nổi tiếng về cuộc sống người nông dân Việt Nam.'),
('Truyện Kiều','Nguyễn Du',70000,'Kiệt tác văn học cổ điển Việt Nam, giàu giá trị nhân văn và nghệ thuật.'),
('Lão Hạc','Nam Cao',45000,'Tác phẩm văn học về tình phụ tử và số phận người nông dân.'),
('Vợ Nhặt','Kim Lân',55000,'Truyện ngắn giàu tình người trong bối cảnh nạn đói năm 1945.'),
('Cây Cam Ngọt Của Tôi','José Mauro de Vasconcelos',105000,'Câu chuyện cảm động về tuổi thơ, gia đình và lòng trắc ẩn.'),
('Hoàng Tử Bé','Antoine de Saint-Exupéry',55000,'Tác phẩm kinh điển dành cho bạn đọc ở nhiều lứa tuổi.'),
('Kính Vạn Hoa - Tập 1','Nguyễn Nhật Ánh',62000,'Tập mở đầu của bộ truyện thiếu nhi giàu tình bạn và tiếng cười.'),
('Không Gia Đình','Hector Malot',120000,'Tiểu thuyết phiêu lưu kinh điển về hành trình trưởng thành.'),
('Tôi Thấy Hoa Vàng Trên Cỏ Xanh','Nguyễn Nhật Ánh',110000,'Câu chuyện tuổi thơ trong trẻo ở một làng quê Việt Nam.'),
('7 Thói Quen Hiệu Quả','Stephen R. Covey',175000,'Những nguyên tắc phát triển bản thân và xây dựng thói quen tích cực.'),
('Tư Duy Nhanh Và Chậm','Daniel Kahneman',190000,'Khám phá hai hệ thống tư duy và cách con người đưa ra quyết định.'),
('Nghĩ Giàu Làm Giàu','Napoleon Hill',90000,'Tác phẩm kinh điển về tư duy mục tiêu, sự kiên trì và thành công.'),
('Người Giàu Có Nhất Thành Babylon','George S. Clason',85000,'Những bài học tài chính cá nhân được kể qua các câu chuyện Babylon.'),
('Để Con Được Ốm','Uyên Bùi, Nguyễn Trí Đoàn',125000,'Chia sẻ kiến thức chăm sóc sức khỏe trẻ nhỏ dành cho cha mẹ.'),
('Bách Khoa Tri Thức Cho Trẻ Em','Nhiều tác giả',155000,'Tập hợp kiến thức phổ thông giúp trẻ khám phá thế giới xung quanh.');

<?php
require 'config.php';
$message = '';

if (isset($_POST['add'])) {
  if (csrf_is_valid($_POST['_csrf'] ?? '')) {
    $id = (int)($_POST['book_id'] ?? 0);
    if ($id > 0) $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
  }
  header('Location: cart.php'); exit;
}
if (isset($_POST['remove'])) {
  if (csrf_is_valid($_POST['_csrf'] ?? '')) unset($_SESSION['cart'][(int)$_POST['remove']]);
  header('Location: cart.php'); exit;
}

$cart = $_SESSION['cart'] ?? [];
$items = [];
$total = 0;
if ($cart) {
  $ids = array_map('intval', array_keys($cart));
  $in = implode(',', array_fill(0, count($ids), '?'));
  $st = $pdo->prepare("SELECT * FROM books WHERE id IN ($in)");
  $st->execute($ids);
  foreach ($st->fetchAll() as $book) {
    $book['qty'] = (int)$cart[$book['id']];
    $book['line_total'] = (float)$book['price'] * $book['qty'];
    $items[] = $book;
    $total += $book['line_total'];
  }
}

$user = null;
if (!empty($_SESSION['user_id'])) {
  $getUser = $pdo->prepare('SELECT id, full_name, email, phone, address FROM users WHERE id = ?');
  $getUser->execute([(int)$_SESSION['user_id']]);
  $user = $getUser->fetch();
}

if (isset($_POST['checkout']) && $items) {
  if (!$user) {
    header('Location: account.php?mode=login&next=cart.php'); exit;
  }
  if (!csrf_is_valid($_POST['_csrf'] ?? '')) {
    $message = 'Phiên đặt hàng đã hết hạn. Hãy tải lại trang rồi thử lại.';
  } else {
    $name = trim($_POST['customer_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['customer_address'] ?? '');
    if ($name === '' || $phone === '' || $address === '') {
      $message = 'Vui lòng nhập họ tên, số điện thoại và địa chỉ nhận hàng.';
    } else {
      try {
        $pdo->beginTransaction();
        $insertOrder = $pdo->prepare('INSERT INTO orders(user_id, customer_name, phone, customer_address, total) VALUES(?,?,?,?,?)');
        $insertOrder->execute([(int)$user['id'], $name, $phone, $address, $total]);
        $orderId = (int)$pdo->lastInsertId();

        $insertDetail = $pdo->prepare('INSERT INTO order_items(order_id, book_id, quantity, price) VALUES(?,?,?,?)');
        foreach ($items as $item) {
          $insertDetail->execute([$orderId, (int)$item['id'], (int)$item['qty'], $item['price']]);
        }
        $updateUser = $pdo->prepare('UPDATE users SET full_name=?, phone=?, address=? WHERE id=?');
        $updateUser->execute([$name, $phone, $address, (int)$user['id']]);
        $_SESSION['user_name'] = $name;
        $pdo->commit();
        unset($_SESSION['cart']);
        header('Location: order_success.php?id=' . $orderId);
        exit;
      } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $message = 'Chưa lưu được đơn hàng. Hãy kiểm tra cấu trúc database đã được cập nhật rồi thử lại.';
      }
    }
  }
}

include 'header.php';
?>
<section class="cart-page">
  <div class="breadcrumbs"><a href="index.php">Trang chủ</a><span>/</span><span>Giỏ hàng</span></div>
  <h1>Giỏ hàng của bạn</h1>
  <?php if ($message): ?><p class="notice"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
  <?php if ($items): ?>
    <div class="cart-layout">
      <div class="cart-items-panel"><table class="cart-table"><thead><tr><th>Sách</th><th>Đơn giá</th><th>Số lượng</th><th>Thành tiền</th><th></th></tr></thead><tbody>
      <?php foreach ($items as $item): ?><tr><td><?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?><small class="cart-author">Tác giả: <?= htmlspecialchars($item['author'], ENT_QUOTES, 'UTF-8') ?></small></td><td><?= number_format($item['price'], 0, ',', '.') ?> đ</td><td><?= (int)$item['qty'] ?></td><td><?= number_format($item['line_total'], 0, ',', '.') ?> đ</td><td><form method="post"><input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><button class="danger" type="submit" name="remove" value="<?= (int)$item['id'] ?>">Xóa</button></form></td></tr><?php endforeach; ?>
      </tbody></table><a class="continue-shopping" href="index.php">← Tiếp tục chọn sách</a></div>
      <aside class="checkout-card"><h2>Thông tin nhận hàng</h2>
        <div class="checkout-total"><span>Tổng cộng</span><strong><?= number_format($total, 0, ',', '.') ?> đ</strong></div>
        <?php if ($user): ?>
        <p class="signed-in-note">Đang đặt hàng với tài khoản <strong><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?></strong>.</p>
        <form method="post" class="checkout-form"><input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
          <label>Họ và tên<input name="customer_name" autocomplete="name" required value="<?= htmlspecialchars($_POST['customer_name'] ?? $user['full_name'], ENT_QUOTES, 'UTF-8') ?>"></label>
          <label>Số điện thoại<input type="tel" name="phone" autocomplete="tel" required value="<?= htmlspecialchars($_POST['phone'] ?? $user['phone'], ENT_QUOTES, 'UTF-8') ?>"></label>
          <label>Địa chỉ nhận hàng<textarea name="customer_address" autocomplete="street-address" rows="3" required><?= htmlspecialchars($_POST['customer_address'] ?? $user['address'], ENT_QUOTES, 'UTF-8') ?></textarea></label>
          <button type="submit" name="checkout" class="checkout-submit">Đặt mua sách</button>
        </form>
        <?php else: ?>
        <p class="login-required">Bạn cần đăng nhập để đặt sách. Giỏ hàng của bạn vẫn được giữ lại.</p>
        <a class="checkout-submit login-to-buy" href="account.php?mode=login&amp;next=cart.php">Đăng nhập để mua</a>
        <a class="register-to-buy" href="account.php?mode=register&amp;next=cart.php">Chưa có tài khoản? Tạo tài khoản</a>
        <?php endif; ?>
      </aside>
    </div>
  <?php else: ?>
    <div class="empty-state"><span aria-hidden="true">🛒</span><h3>Giỏ hàng của bạn đang trống</h3><p>Chọn vài cuốn sách bạn yêu thích rồi quay lại đây nhé.</p><a href="index.php" class="text-link">Khám phá sách <span aria-hidden="true">→</span></a></div>
  <?php endif; ?>
</section>
<?php include 'footer.php'; ?>

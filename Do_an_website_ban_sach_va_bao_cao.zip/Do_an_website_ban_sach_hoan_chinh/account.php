<?php
require 'config.php';

$mode = ($_GET['mode'] ?? 'login') === 'register' ? 'register' : 'login';
$next = ($_POST['next'] ?? $_GET['next'] ?? '') === 'cart.php' ? 'cart.php' : 'index.php';
$error = '';
$notice = isset($_GET['registered']) ? 'Tài khoản đã được tạo. Bạn đang đăng nhập.' : (isset($_GET['loggedout']) ? 'Bạn đã đăng xuất khỏi tài khoản.' : '');
$old = ['full_name' => '', 'email' => '', 'phone' => '', 'address' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  $mode = $action === 'register' ? 'register' : 'login';
  if (!csrf_is_valid($_POST['_csrf'] ?? '')) {
    $error = 'Phiên làm việc đã hết hạn. Hãy tải lại trang rồi thử lại.';
  } elseif ($action === 'register') {
    $old['full_name'] = trim($_POST['full_name'] ?? '');
    $old['email'] = strtolower(trim($_POST['email'] ?? ''));
    $old['phone'] = trim($_POST['phone'] ?? '');
    $old['address'] = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($old['full_name'] === '' || $old['phone'] === '' || $old['address'] === '') {
      $error = 'Vui lòng nhập họ tên, số điện thoại và địa chỉ.';
    } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
      $error = 'Email chưa đúng định dạng.';
    } elseif (strlen($password) < 8) {
      $error = 'Mật khẩu cần có ít nhất 8 ký tự.';
    } elseif ($password !== $confirm) {
      $error = 'Mật khẩu nhập lại chưa khớp.';
    } else {
      $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
      $check->execute([$old['email']]);
      if ($check->fetch()) {
        $error = 'Email này đã có tài khoản. Hãy đăng nhập thay vì đăng ký lại.';
      } else {
        try {
          $insert = $pdo->prepare('INSERT INTO users(full_name, email, phone, address, password_hash) VALUES(?,?,?,?,?)');
          $insert->execute([$old['full_name'], $old['email'], $old['phone'], $old['address'], password_hash($password, PASSWORD_DEFAULT)]);
          session_regenerate_id(true);
          $_SESSION['user_id'] = (int)$pdo->lastInsertId();
          $_SESSION['user_name'] = $old['full_name'];
          $_SESSION['user_email'] = $old['email'];
          header('Location: ' . ($next === 'cart.php' ? 'cart.php' : 'account.php?registered=1'));
          exit;
        } catch (PDOException $e) {
          $error = 'Chưa tạo được tài khoản. Hãy kiểm tra lại thông tin rồi thử lại.';
        }
      }
    }
  } elseif ($action === 'login') {
    $old['email'] = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $find = $pdo->prepare('SELECT id, full_name, email, password_hash FROM users WHERE email = ?');
    $find->execute([$old['email']]);
    $account = $find->fetch();
    if (!$account || !password_verify($password, $account['password_hash'])) {
      $error = 'Email hoặc mật khẩu chưa chính xác.';
    } else {
      session_regenerate_id(true);
      $_SESSION['user_id'] = (int)$account['id'];
      $_SESSION['user_name'] = $account['full_name'];
      $_SESSION['user_email'] = $account['email'];
      header('Location: ' . ($next === 'cart.php' ? 'cart.php' : 'account.php'));
      exit;
    }
  }
}

$user = null;
$userOrders = [];
if (!empty($_SESSION['user_id'])) {
  $getUser = $pdo->prepare('SELECT id, full_name, email, phone, address FROM users WHERE id = ?');
  $getUser->execute([(int)$_SESSION['user_id']]);
  $user = $getUser->fetch();
  if ($user) {
    $getOrders = $pdo->prepare('SELECT id, total, customer_address, created_at FROM orders WHERE user_id = ? ORDER BY id DESC');
    $getOrders->execute([$user['id']]);
    $userOrders = $getOrders->fetchAll();
  } else {
    unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_email']);
  }
}
include 'header.php';
?>
<section class="account-page">
  <?php if ($user): ?>
    <div class="account-heading"><span class="account-kicker">TÀI KHOẢN NHÀ SÁCH NHỎ</span><h1>Xin chào, <?= htmlspecialchars($user['full_name'], ENT_QUOTES, 'UTF-8') ?></h1><p>Thông tin nhận hàng của bạn được dùng để điền nhanh khi đặt sách.</p></div>
    <?php if ($notice): ?><p class="notice"><?= htmlspecialchars($notice, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
    <div class="account-columns">
      <section class="account-card"><h2>Thông tin tài khoản</h2><dl class="profile-list"><div><dt>Họ và tên</dt><dd><?= htmlspecialchars($user['full_name'], ENT_QUOTES, 'UTF-8') ?></dd></div><div><dt>Email</dt><dd><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?></dd></div><div><dt>Số điện thoại</dt><dd><?= htmlspecialchars($user['phone'], ENT_QUOTES, 'UTF-8') ?></dd></div><div><dt>Địa chỉ nhận hàng</dt><dd><?= nl2br(htmlspecialchars($user['address'], ENT_QUOTES, 'UTF-8')) ?></dd></div></dl><form method="post" action="logout.php"><input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><button class="logout-button" type="submit">Đăng xuất</button></form></section>
      <section class="account-card order-history"><h2>Đơn hàng của tôi</h2>
        <?php if ($userOrders): ?><div class="order-list">
          <?php foreach ($userOrders as $order): ?><a class="order-row" href="order_success.php?id=<?= (int)$order['id'] ?>"><span><strong>Đơn hàng #<?= (int)$order['id'] ?></strong><small><?= htmlspecialchars($order['created_at'], ENT_QUOTES, 'UTF-8') ?></small></span><span class="order-row-end"><strong><?= number_format($order['total'], 0, ',', '.') ?> đ</strong><small>Xem chi tiết →</small></span></a><?php endforeach; ?>
        </div><?php else: ?><p class="account-empty">Bạn chưa có đơn hàng nào. <a href="index.php">Khám phá sách</a>.</p><?php endif; ?>
      </section>
    </div>
  <?php else: ?>
    <div class="auth-intro"><span class="account-kicker">TÀI KHOẢN NHÀ SÁCH NHỎ</span><h1><?= $mode === 'register' ? 'Tạo tài khoản mới' : 'Đăng nhập để tiếp tục' ?></h1><p>Tạo tài khoản để lưu địa chỉ nhận hàng và xem lại các đơn sách đã đặt.</p></div>
    <div class="auth-card">
      <div class="auth-tabs"><a class="<?= $mode === 'login' ? 'selected' : '' ?>" href="account.php?mode=login<?= $next === 'cart.php' ? '&next=cart.php' : '' ?>">Đăng nhập</a><a class="<?= $mode === 'register' ? 'selected' : '' ?>" href="account.php?mode=register<?= $next === 'cart.php' ? '&next=cart.php' : '' ?>">Tạo tài khoản</a></div>
      <?php if ($error): ?><p class="form-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
      <?php if ($mode === 'register'): ?>
      <form method="post" class="auth-form"><input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="register"><input type="hidden" name="next" value="<?= htmlspecialchars($next, ENT_QUOTES, 'UTF-8') ?>">
        <label>Họ và tên<input name="full_name" autocomplete="name" required value="<?= htmlspecialchars($old['full_name'], ENT_QUOTES, 'UTF-8') ?>"></label>
        <label>Email<input type="email" name="email" autocomplete="email" required value="<?= htmlspecialchars($old['email'], ENT_QUOTES, 'UTF-8') ?>"></label>
        <label>Số điện thoại<input type="tel" name="phone" autocomplete="tel" required value="<?= htmlspecialchars($old['phone'], ENT_QUOTES, 'UTF-8') ?>"></label>
        <label>Địa chỉ nhận hàng<input name="address" autocomplete="street-address" required value="<?= htmlspecialchars($old['address'], ENT_QUOTES, 'UTF-8') ?>"></label>
        <label>Mật khẩu <small>(ít nhất 8 ký tự)</small><input type="password" name="password" autocomplete="new-password" minlength="8" required></label>
        <label>Nhập lại mật khẩu<input type="password" name="confirm_password" autocomplete="new-password" minlength="8" required></label>
        <button type="submit" class="auth-submit">Tạo tài khoản</button>
      </form>
      <?php else: ?>
      <form method="post" class="auth-form"><input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="login"><input type="hidden" name="next" value="<?= htmlspecialchars($next, ENT_QUOTES, 'UTF-8') ?>">
        <label>Email<input type="email" name="email" autocomplete="email" required value="<?= htmlspecialchars($old['email'], ENT_QUOTES, 'UTF-8') ?>"></label>
        <label>Mật khẩu<input type="password" name="password" autocomplete="current-password" required></label>
        <button type="submit" class="auth-submit">Đăng nhập</button>
      </form>
      <?php endif; ?>
      <p class="auth-footnote">Mật khẩu được lưu dưới dạng mã băm trong database, không lưu nguyên văn.</p>
    </div>
  <?php endif; ?>
</section>
<?php include 'footer.php'; ?>

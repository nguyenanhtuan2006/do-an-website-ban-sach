# Đồ án website bán sách — Nhà Sách Nhỏ

## Cài lần đầu

1. Mở XAMPP, bật **Apache** và **MySQL**.
2. Chép thư mục dự án vào `C:\xampp\htdocs\do_an_website_ban_sach\`.
3. Mở `http://localhost/phpmyadmin`.
4. Chọn tab **Import**, chọn đúng tệp `database.sql`, rồi bấm **Go**.
5. Mở `http://localhost/do_an_website_ban_sach/`.

`database.sql` tạo các bảng sách, tài khoản, đơn hàng, chi tiết đơn, tin nhắn liên hệ và 19 sách mẫu. Giá sách mẫu chỉ để minh họa đồ án.

## Cập nhật database đã có sẵn

Trong phpMyAdmin, chọn database **ban_sach** trước khi nhập. Nhập từng tệp `.sql` riêng:

1. `add_more_books.sql` thêm các sách mẫu còn thiếu; có thể chạy lại nếu tên sách đã có.
2. `migration_account_address.sql` tạo bảng tài khoản và thêm cột cho địa chỉ/người đặt vào bảng đơn hàng. Chạy tệp migration này **đúng một lần** trên database phiên bản cũ.
3. `migration_contact_messages.sql` tạo bảng lưu biểu mẫu liên hệ; chạy một lần nếu database cũ chưa có bảng `contact_messages`.

**Không chọn ZIP, PHP, CSS, JavaScript hoặc README để nhập bằng phpMyAdmin.** ZIP là gói dự án cần giải nén vào thư mục `htdocs`; phpMyAdmin chỉ nhận tệp `.sql`. Không dán mã bắt đầu bằng `<?php` vào ô SQL.

Nếu báo lỗi migration vì cột `user_id` hoặc `customer_address` đã tồn tại, có thể schema đã được nâng cấp trước đó; không chạy lại lệnh `ALTER TABLE`. Kiểm tra trong bảng `orders` hai cột đó và bảng `users` đã có chưa.

## Tài khoản và đặt hàng

Mở **Đăng nhập** trên thanh đầu trang để đăng nhập hoặc tạo tài khoản. Đăng ký cần họ tên, email, số điện thoại, địa chỉ và mật khẩu ít nhất 8 ký tự. Khi đặt hàng, website yêu cầu đăng nhập; địa chỉ có thể chỉnh lại trong biểu mẫu checkout. Sau khi đặt thành công, đơn hàng lưu bản chụp địa chỉ giao hàng, chi tiết sách và tổng tiền. Trang tài khoản hiển thị lịch sử đơn hàng của người đang đăng nhập.

Mật khẩu được lưu bằng `password_hash`; trang xem đơn hàng chỉ cho tài khoản sở hữu đơn hàng đó truy cập. Đây là đồ án mẫu, chưa có thanh toán trực tuyến, xác thực email, quên mật khẩu hoặc đăng nhập quản trị.

## Chức năng cửa hàng

- Tìm kiếm theo tên sách/tác giả.
- Lọc danh mục và khoảng giá, sắp xếp trên trình duyệt.
- Giỏ hàng, đặt mua khi đã đăng nhập, lưu địa chỉ theo từng đơn và trang xác nhận thành công.
- Quản trị sách và xem 10 đơn hàng gần nhất.
- Trang `contact.php` nhận góp ý/hỗ trợ; dữ liệu được kiểm tra CSRF, xác thực và lưu bằng prepared statement vào bảng `contact_messages`.

Danh mục mẫu nằm trong `$categoryMap` của `index.php`; khi thêm sách từ trang quản trị, sách chưa được ánh xạ sẽ hiện trong nhóm **Khác**.

## Liên hệ

Mở **Liên hệ** trên thanh danh mục, điền biểu mẫu và gửi. Tin nhắn được lưu vào bảng `contact_messages`; có thể xem trong phpMyAdmin sau khi chọn database `ban_sach`. Phiên bản đồ án chưa gửi email tự động và chưa có màn hình quản trị riêng cho các tin nhắn.

<?php
require 'config.php';
if (empty($_SESSION['user_id'])) {
  header('Location: account.php?mode=login');
  exit;
}
$orderId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$order = null;
$orderItems = [];
if ($orderId) {
  $findOrder = $pdo->prepare('SELECT id, customer_name, phone, customer_address, total, created_at FROM orders WHERE id = ? AND user_id = ?');
  $findOrder->execute([$orderId, (int)$_SESSION['user_id']]);
  $order = $findOrder->fetch();
  if ($order) {
    $findItems = $pdo->prepare('SELECT b.title, oi.quantity, oi.price FROM order_items oi JOIN books b ON b.id = oi.book_id WHERE oi.order_id = ?');
    $findItems->execute([$orderId]);
    $orderItems = $findItems->fetchAll();
  }
}
include 'header.php';
?>
<section class="success-page">
  <?php if ($order): ?>
    <div class="success-mark" aria-hidden="true">✓</div>
    <p class="account-kicker">ĐẶT HÀNG THÀNH CÔNG</p>
    <h1>Cảm ơn bạn đã mua sách!</h1>
    <p class="success-lead">Đơn hàng <strong>#<?= (int)$order['id'] ?></strong> đã được ghi nhận. Thông tin giao hàng được lưu bên dưới.</p>
    <div class="success-details">
      <section class="account-card"><h2>Địa chỉ nhận hàng</h2><p class="address-name"><?= htmlspecialchars($order['customer_name'], ENT_QUOTES, 'UTF-8') ?></p><p><?= htmlspecialchars($order['phone'], ENT_QUOTES, 'UTF-8') ?></p><p><?= nl2br(htmlspecialchars($order['customer_address'], ENT_QUOTES, 'UTF-8')) ?></p><small>Ngày đặt: <?= htmlspecialchars($order['created_at'], ENT_QUOTES, 'UTF-8') ?></small></section>
      <section class="account-card"><h2>Sách đã đặt</h2><div class="success-items">
        <?php foreach ($orderItems as $item): ?><div class="success-item"><span><?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?><small>Số lượng: <?= (int)$item['quantity'] ?></small></span><strong><?= number_format((float)$item['price'] * (int)$item['quantity'], 0, ',', '.') ?> đ</strong></div><?php endforeach; ?>
      </div><div class="success-total"><span>Tổng cộng</span><strong><?= number_format($order['total'], 0, ',', '.') ?> đ</strong></div></section>
    </div>
    <div class="success-actions"><a class="checkout-submit" href="index.php">Tiếp tục mua sách</a><a class="success-account-link" href="account.php">Xem tài khoản và đơn hàng</a></div>
  <?php else: ?>
    <div class="empty-state"><span aria-hidden="true">⌕</span><h3>Không tìm thấy đơn hàng</h3><p>Đơn hàng không tồn tại hoặc không thuộc tài khoản đang đăng nhập.</p><a class="text-link" href="account.php">Quay lại tài khoản</a></div>
  <?php endif; ?>
</section>
<?php include 'footer.php'; ?>

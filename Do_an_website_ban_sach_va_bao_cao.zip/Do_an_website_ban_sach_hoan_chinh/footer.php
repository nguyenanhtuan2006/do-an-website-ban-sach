</main>
<footer class="site-footer"><a class="footer-brand" href="index.php">Nhà Sách Nhỏ</a><span>© 2026 · Một góc nhỏ cho những người yêu đọc.</span><a href="index.php">Trở về đầu trang ↑</a></footer>
<div class="toast" id="toast" role="status" aria-live="polite"><span class="toast-check" aria-hidden="true">✓</span><span class="toast-message">Đã thêm thành công</span></div>
<script src="assets/app.js?v=20261020-5" defer></script>
</body>
</html>

GÓI ĐỒ ÁN NHÀ SÁCH NHỎ

- Mã nguồn website PHP/MySQL nằm ở thư mục gốc.
- Báo cáo Word đã cập nhật trang Liên hệ, bảng contact_messages, UC09, sơ đồ, route và kịch bản kiểm thử.
- PDF là bản xem trước đã xuất từ Word.
- Cài mới: xem README.md ở thư mục gốc và nhập database.sql vào database ban_sach.
- Database cũ: chỉ chạy migration_contact_messages.sql khi chưa có bảng contact_messages; không nhập tệp PHP/ZIP vào phpMyAdmin.
- Dùng XAMPP/Apache/MySQL theo README. Form liên hệ lưu tin nhắn vào CSDL, chưa gửi email tự động.

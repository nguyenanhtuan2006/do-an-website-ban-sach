<?php
require 'config.php';
$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'delete') {
    $st = $pdo->prepare("DELETE FROM books WHERE id=?"); $st->execute([(int)$_POST['id']]);
    $notice = 'Đã xóa sách.';
  } elseif ($action === 'save') {
    $id = (int)($_POST['id'] ?? 0); $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? ''); $price = (float)($_POST['price'] ?? 0);
    $desc = trim($_POST['description'] ?? '');
    if ($title && $author && $price >= 0) {
      if ($id) {
        $st = $pdo->prepare("UPDATE books SET title=?,author=?,price=?,description=? WHERE id=?");
        $st->execute([$title,$author,$price,$desc,$id]); $notice = 'Đã cập nhật sách.';
      } else {
        $st = $pdo->prepare("INSERT INTO books(title,author,price,description) VALUES(?,?,?,?)");
        $st->execute([$title,$author,$price,$desc]); $notice = 'Đã thêm sách.';
      }
    } else $notice = 'Vui lòng nhập tên sách, tác giả và giá hợp lệ.';
  }
}
$edit = null;
if (isset($_GET['edit'])) { $st=$pdo->prepare("SELECT * FROM books WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit=$st->fetch(); }
$books = $pdo->query("SELECT * FROM books ORDER BY id DESC")->fetchAll();
$orders = $pdo->query("SELECT * FROM orders ORDER BY id DESC LIMIT 10")->fetchAll();
include 'header.php';
?>
<h1>Quản trị sách</h1><p class="muted">Bản demo phục vụ đồ án học tập; chưa có đăng nhập quản trị.</p>
<?php if ($notice): ?><p class="notice"><?= htmlspecialchars($notice) ?></p><?php endif; ?>
<section class="panel"><h2><?= $edit ? 'Sửa sách' : 'Thêm sách mới' ?></h2>
<form method="post" class="admin-form">
<input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= $edit['id'] ?? 0 ?>">
<label>Tên sách<input name="title" required value="<?= htmlspecialchars($edit['title'] ?? '') ?>"></label>
<label>Tác giả<input name="author" required value="<?= htmlspecialchars($edit['author'] ?? '') ?>"></label>
<label>Giá (VNĐ)<input type="number" min="0" name="price" required value="<?= htmlspecialchars($edit['price'] ?? '') ?>"></label>
<label>Mô tả<input name="description" value="<?= htmlspecialchars($edit['description'] ?? '') ?>"></label>
<button>Lưu sách</button><?php if ($edit): ?> <a href="admin.php">Hủy sửa</a><?php endif; ?>
</form></section>
<h2>Danh sách sách</h2><table><tr><th>ID</th><th>Tên sách</th><th>Tác giả</th><th>Giá</th><th>Thao tác</th></tr>
<?php foreach ($books as $b): ?><tr><td><?= $b['id'] ?></td><td><?= htmlspecialchars($b['title']) ?></td><td><?= htmlspecialchars($b['author']) ?></td><td><?= number_format($b['price'],0,',','.') ?> đ</td><td><a href="?edit=<?= $b['id'] ?>">Sửa</a> <form class="inline" method="post" onsubmit="return confirm('Bạn chắc chắn muốn xóa sách này?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $b['id'] ?>"><button class="danger">Xóa</button></form></td></tr><?php endforeach; ?>
</table>
<h2>10 đơn hàng gần nhất</h2><table><tr><th>Mã</th><th>Khách hàng</th><th>SĐT</th><th>Địa chỉ giao hàng</th><th>Tổng tiền</th><th>Ngày đặt</th></tr>
<?php foreach ($orders as $o): ?><tr><td>#<?= $o['id'] ?></td><td><?= htmlspecialchars($o['customer_name']) ?></td><td><?= htmlspecialchars($o['phone']) ?></td><td><?= htmlspecialchars($o['customer_address'] ?? '') ?></td><td><?= number_format($o['total'],0,',','.') ?> đ</td><td><?= htmlspecialchars($o['created_at']) ?></td></tr><?php endforeach; ?>
</table>
<?php include 'footer.php'; ?>

(() => {
  'use strict';

  const toast = document.getElementById('toast');
  let toastTimer;

  function showToast(message) {
    if (!toast) return;
    const text = toast.querySelector('.toast-message');
    if (text) text.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3200);
  }

  // Lưu tín hiệu trước khi gửi form; cart.php xử lý POST rồi redirect về chính nó.
  document.querySelectorAll('[data-cart-form]').forEach((form) => {
    form.addEventListener('submit', () => {
      try { window.sessionStorage.setItem('bookstore-cart-added', '1'); } catch (_) {}
    });
  });

  try {
    if (window.sessionStorage.getItem('bookstore-cart-added') === '1') {
      window.sessionStorage.removeItem('bookstore-cart-added');
      window.setTimeout(() => showToast('Đã thêm thành công'), 180);
    }
  } catch (_) {}

  const cards = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, currentObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          currentObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px 30px 0px' });
    cards.forEach((card, index) => {
      card.style.transitionDelay = `${Math.min(index % 4, 3) * 65}ms`;
      observer.observe(card);
    });
  } else {
    cards.forEach((card) => card.classList.add('is-visible'));
  }

  // Lọc và sắp xếp thẻ sách đã có trong HTML; không gửi request tới PHP.
  const categoryButtons = document.querySelectorAll('.filter-button, .strip-category[data-filter]');
  const priceButtons = document.querySelectorAll('.price-filter');
  const bookCards = Array.from(document.querySelectorAll('.grid .book'));
  const bookGrid = document.querySelector('.grid');
  const filterEmpty = document.querySelector('.filter-empty');
  const sortSelect = document.getElementById('book-sort');
  const visibleCounter = document.querySelector('.intro-count strong');
  let selectedCategory = 'all';
  let selectedPrice = 'all';

  function matchesPrice(price) {
    if (selectedPrice === 'under-100') return price < 100000;
    if (selectedPrice === '100-200') return price >= 100000 && price <= 200000;
    if (selectedPrice === 'over-200') return price > 200000;
    return true;
  }

  function updateCatalog() {
    const sortOrder = sortSelect ? sortSelect.value : 'newest';
    const sortedCards = [...bookCards].sort((a, b) => {
      const priceA = Number(a.dataset.price || 0);
      const priceB = Number(b.dataset.price || 0);
      if (sortOrder === 'price-low') return priceA - priceB;
      if (sortOrder === 'price-high') return priceB - priceA;
      return Number(b.dataset.id || 0) - Number(a.dataset.id || 0);
    });

    let visibleCount = 0;
    sortedCards.forEach((card) => {
      if (bookGrid) bookGrid.appendChild(card);
      const categoryMatches = selectedCategory === 'all' ||
        card.dataset.category === selectedCategory;
      const priceMatches = matchesPrice(Number(card.dataset.price || 0));
      card.hidden = !(categoryMatches && priceMatches);
      if (!card.hidden) visibleCount += 1;
    });

    if (filterEmpty) filterEmpty.hidden = visibleCount > 0;
    if (visibleCounter) visibleCounter.textContent = String(visibleCount);
  }

  categoryButtons.forEach((button) => {
    button.addEventListener('click', (event) => {
      if (button.classList.contains('strip-category') && bookGrid) event.preventDefault();
      selectedCategory = button.dataset.filter || 'all';
      categoryButtons.forEach((item) => {
        const active = item.dataset.filter === selectedCategory;
        item.classList.toggle('is-active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      updateCatalog();
    });
  });

  priceButtons.forEach((button) => {
    button.addEventListener('click', () => {
      selectedPrice = button.dataset.priceFilter || 'all';
      priceButtons.forEach((item) => {
        const active = item.dataset.priceFilter === selectedPrice;
        item.classList.toggle('is-active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      updateCatalog();
    });
  });

  if (sortSelect) sortSelect.addEventListener('change', updateCatalog);
})();

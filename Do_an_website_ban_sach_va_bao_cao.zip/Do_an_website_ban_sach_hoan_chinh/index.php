<?php
require 'config.php';
$q = trim($_GET['q'] ?? '');
if ($q !== '') {
  $stmt = $pdo->prepare("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? ORDER BY id DESC");
  $stmt->execute(["%$q%", "%$q%"]);
} else {
  $stmt = $pdo->query("SELECT * FROM books ORDER BY id DESC");
}
$books = $stmt->fetchAll();
$categoryMap = [
  'Dế Mèn Phiêu Lưu Ký' => 'thieu-nhi',
  'Tuổi Trẻ Đáng Giá Bao Nhiêu' => 'ky-nang',
  'Nhà Giả Kim' => 'van-hoc',
  'Đắc Nhân Tâm' => 'ky-nang',
  'Tắt Đèn' => 'van-hoc',
  'Truyện Kiều' => 'van-hoc',
  'Lão Hạc' => 'van-hoc',
  'Vợ Nhặt' => 'van-hoc',
  'Cây Cam Ngọt Của Tôi' => 'van-hoc',
  'Hoàng Tử Bé' => 'thieu-nhi',
  'Kính Vạn Hoa - Tập 1' => 'thieu-nhi',
  'Không Gia Đình' => 'thieu-nhi',
  'Tôi Thấy Hoa Vàng Trên Cỏ Xanh' => 'van-hoc',
  '7 Thói Quen Hiệu Quả' => 'ky-nang',
  'Tư Duy Nhanh Và Chậm' => 'ky-nang',
  'Nghĩ Giàu Làm Giàu' => 'kinh-doanh',
  'Người Giàu Có Nhất Thành Babylon' => 'kinh-doanh',
  'Để Con Được Ốm' => 'me-be',
  'Bách Khoa Tri Thức Cho Trẻ Em' => 'tham-khao',
];
$categoryLabels = ['van-hoc' => 'Văn học', 'thieu-nhi' => 'Thiếu nhi', 'ky-nang' => 'Kỹ năng sống', 'kinh-doanh' => 'Kinh doanh', 'me-be' => 'Mẹ và bé', 'tham-khao' => 'Tham khảo', 'khac' => 'Khác'];
include 'header.php';
?>
<div class="store-intro">
  <div class="breadcrumbs"><a href="index.php">Trang chủ</a><span>/</span><span><?= $q !== '' ? 'Tìm kiếm' : 'Danh mục sách' ?></span></div>
  <div class="intro-copy"><span class="intro-kicker">NHÀ SÁCH NHỎ · GÓC ĐỌC CỦA BẠN</span><h1><?= $q !== '' ? 'Kết quả tìm kiếm' : 'Sách hay, ngày thêm vui' ?></h1><p><?= $q !== '' ? 'Đang tìm: “' . htmlspecialchars($q, ENT_QUOTES, 'UTF-8') . '”' : 'Chọn một cuốn sách hợp với tâm trạng hôm nay.' ?></p></div>
  <div class="intro-count"><strong><?= count($books) ?></strong><span><?= count($books) === 1 ? 'cuốn sách' : 'cuốn sách' ?></span></div>
</div>

<div class="store-layout" id="book-list">
  <aside class="store-sidebar" aria-label="Lọc danh sách sách">
    <div class="sidebar-section">
      <h2 class="sidebar-title"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16M4 12h16M4 19h16"></path></svg>Danh mục sách</h2>
      <div class="category-list" role="group" aria-label="Lọc theo thể loại">
        <button type="button" class="filter-button is-active" data-filter="all" aria-pressed="true"><span>Tất cả sách</span><span class="category-arrow">›</span></button>
        <button type="button" class="filter-button" data-filter="thieu-nhi" aria-pressed="false"><span>Sách thiếu nhi</span><span class="category-arrow">›</span></button>
        <button type="button" class="filter-button" data-filter="van-hoc" aria-pressed="false"><span>Văn học</span><span class="category-arrow">›</span></button>
        <button type="button" class="filter-button" data-filter="ky-nang" aria-pressed="false"><span>Kỹ năng sống</span><span class="category-arrow">›</span></button>
        <button type="button" class="filter-button" data-filter="kinh-doanh" aria-pressed="false"><span>Kinh doanh</span><span class="category-arrow">›</span></button>
        <button type="button" class="filter-button" data-filter="me-be" aria-pressed="false"><span>Mẹ và bé</span><span class="category-arrow">›</span></button>
        <button type="button" class="filter-button" data-filter="tham-khao" aria-pressed="false"><span>Tham khảo</span><span class="category-arrow">›</span></button>
        <button type="button" class="filter-button" data-filter="khac" aria-pressed="false"><span>Khác</span><span class="category-arrow">›</span></button>
      </div>
    </div>
    <div class="sidebar-section price-section">
      <h2 class="sidebar-title"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2v20m5-15.5C17 4.6 14.9 3.5 12 3.5S7 4.8 7 7s1.8 3.2 5 4 5 1.5 5 4-2.2 4-5 4-5-1.2-5-3"></path></svg>Lọc theo giá</h2>
      <div class="price-list" role="group" aria-label="Lọc theo khoảng giá">
        <button type="button" class="price-filter is-active" data-price-filter="all" aria-pressed="true"><span class="radio-dot"></span>Tất cả mức giá</button>
        <button type="button" class="price-filter" data-price-filter="under-100" aria-pressed="false"><span class="radio-dot"></span>Dưới 100.000 đ</button>
        <button type="button" class="price-filter" data-price-filter="100-200" aria-pressed="false"><span class="radio-dot"></span>100.000 – 200.000 đ</button>
        <button type="button" class="price-filter" data-price-filter="over-200" aria-pressed="false"><span class="radio-dot"></span>Trên 200.000 đ</button>
      </div>
    </div>
    <div class="sidebar-note"><span class="note-icon" aria-hidden="true">✦</span><strong>Một cuốn sách cho riêng bạn</strong><p>Duyệt sách theo thể loại hoặc khoảng giá để tìm lựa chọn phù hợp.</p></div>
  </aside>

  <section class="store-main" aria-label="Danh sách sách">
    <div class="list-toolbar"><div><span class="toolbar-label">BỘ SƯU TẬP</span><h2><?= $q !== '' ? 'Sách phù hợp với tìm kiếm' : 'Những cuốn sách nổi bật' ?></h2></div><div class="sort-control"><label for="book-sort">Sắp xếp:</label><select id="book-sort" aria-label="Sắp xếp sách"><option value="newest">Mới nhất</option><option value="price-low">Giá thấp đến cao</option><option value="price-high">Giá cao đến thấp</option></select></div></div>

    <?php if ($books): ?>
    <div class="grid">
      <?php foreach ($books as $index => $book): ?>
      <?php $category = $categoryMap[$book['title']] ?? 'khac'; $categoryLabel = $categoryLabels[$category] ?? 'Khác'; ?>
      <article class="book reveal" data-category="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>" data-price="<?= (float)$book['price'] ?>" data-id="<?= (int)$book['id'] ?>">
        <div class="cover cover-<?= $index % 5 ?>">
          <span class="cover-label">NHÀ SÁCH NHỎ</span>
          <span class="cover-mark" aria-hidden="true">✳</span>
          <span class="cover-title"><?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8') ?></span>
          <span class="cover-author"><?= htmlspecialchars($book['author'], ENT_QUOTES, 'UTF-8') ?></span>
        </div>
        <div class="book-info">
          <p class="book-category"><?= htmlspecialchars($categoryLabel, ENT_QUOTES, 'UTF-8') ?></p>
          <h3><?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8') ?></h3>
          <p class="muted">Tác giả <span>·</span> <?= htmlspecialchars($book['author'], ENT_QUOTES, 'UTF-8') ?></p>
          <?php if (!empty($book['description'])): ?><p class="book-description"><?= htmlspecialchars($book['description'], ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
          <div class="book-bottom"><p class="price"><?= number_format($book['price'], 0, ',', '.') ?><small> đ</small></p>
            <form method="post" action="cart.php" data-cart-form><input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="book_id" value="<?= (int)$book['id'] ?>"><button class="add-button" type="submit" name="add" aria-label="Thêm <?= htmlspecialchars($book['title'], ENT_QUOTES, 'UTF-8') ?> vào giỏ hàng"><span>Thêm vào giỏ</span><span class="button-plus" aria-hidden="true">+</span></button></form>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
    <p class="filter-empty" hidden>Không có sách phù hợp với lựa chọn này.</p>
    <?php else: ?>
      <div class="empty-state"><span aria-hidden="true">⌕</span><h3>Chưa tìm thấy cuốn sách phù hợp</h3><p>Thử tên sách hoặc tác giả khác nhé.</p><a href="index.php" class="text-link">Xem tất cả sách <span aria-hidden="true">→</span></a></div>
    <?php endif; ?>
  </section>
</div>
<?php include 'footer.php'; ?>

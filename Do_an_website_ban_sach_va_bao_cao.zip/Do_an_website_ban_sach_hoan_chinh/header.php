<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#ffffff">
<title>Nhà Sách Nhỏ — Ươm mầm thói quen đọc</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css?v=20261020-6">
</head>
<body>
<header class="site-header">
  <div class="topbar">
    <a class="brand" href="index.php" aria-label="Nhà Sách Nhỏ - Trang chủ">
      <span class="brand-icon" aria-hidden="true"><svg viewBox="0 0 32 32"><path d="M5 7.5c4.2-1.5 7.9-.8 11 1.7v17c-3.1-2.5-6.8-3.2-11-1.7zM27 7.5c-4.2-1.5-7.9-.8-11 1.7v17c3.1-2.5 6.8-3.2 11-1.7z"/><path d="M16 9v17"/></svg></span>
      <span class="brand-name"><strong>NHÀ SÁCH</strong><small>NHỎ</small></span>
    </a>
    <form class="header-search" action="index.php" method="get" role="search">
      <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m16 16 4.5 4.5"></path></svg>
      <input type="search" name="q" value="<?= htmlspecialchars($q ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Tìm tên sách hoặc tác giả..." aria-label="Tìm sách">
      <button type="submit">Tìm kiếm</button>
    </form>
    <nav class="header-actions" aria-label="Tài khoản và giỏ hàng">
      <a class="action-link account-action" href="account.php"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"></circle><path d="M5 20a7 7 0 0 1 14 0"></path></svg><span><?= isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name'], ENT_QUOTES, 'UTF-8') : 'Đăng nhập' ?></span></a>
      <a class="cart-link" href="cart.php" aria-label="Giỏ hàng, <?= array_sum($_SESSION['cart'] ?? []) ?> sản phẩm"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h2l2.1 10.1a2 2 0 0 0 2 1.6h7.8a2 2 0 0 0 1.9-1.4L21 8H6"></path><circle cx="9.5" cy="19" r="1.3"></circle><circle cx="17.5" cy="19" r="1.3"></circle></svg><span class="cart-label">Giỏ hàng</span><span class="cart-badge"><?= array_sum($_SESSION['cart'] ?? []) ?></span></a>
    </nav>
  </div>
  <div class="category-strip">
    <nav class="strip-inner" aria-label="Danh mục sách">
      <a class="strip-home" href="index.php"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-6v-7h-4v7H4a1 1 0 0 1-1-1z"></path></svg>Trang chủ</a>
      <a class="strip-category is-active" role="button" href="index.php#book-list" data-filter="all" aria-pressed="true">Tất cả</a>
      <a class="strip-category" role="button" href="index.php#book-list" data-filter="thieu-nhi" aria-pressed="false">Sách thiếu nhi</a>
      <a class="strip-category" role="button" href="index.php#book-list" data-filter="van-hoc" aria-pressed="false">Văn học</a>
      <a class="strip-category" role="button" href="index.php#book-list" data-filter="ky-nang" aria-pressed="false">Kỹ năng sống</a>
      <a class="strip-category" role="button" href="index.php#book-list" data-filter="kinh-doanh" aria-pressed="false">Kinh doanh</a>
      <a class="strip-category" role="button" href="index.php#book-list" data-filter="me-be" aria-pressed="false">Mẹ và bé</a>
      <a class="strip-category" role="button" href="index.php#book-list" data-filter="tham-khao" aria-pressed="false">Tham khảo</a>
      <a class="strip-category strip-contact" href="contact.php">Liên hệ</a>
      <a class="strip-category strip-admin" href="admin.php">Quản trị</a>
    </nav>
  </div>
</header>
<main class="container">
